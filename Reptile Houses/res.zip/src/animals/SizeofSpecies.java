package animals;

/** Lets the user choose a specified size for a specie. */
public enum SizeofSpecies {
  SMALL,
  MEDIUM,
  LARGE
}
