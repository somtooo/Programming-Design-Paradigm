package animals;

/** Lets the user choose the type of species between a reptile or amphibian. */
public enum TypeOfSpecies {
  REPTILE,
  AMPHIBIAN;

}
