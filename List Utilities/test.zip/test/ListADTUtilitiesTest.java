import static org.junit.Assert.*;

public class ListADTUtilitiesTest {

    @org.junit.Before
    public void setUp() throws Exception {
    }

    @org.junit.Test
    public void toList() {
    }

    @org.junit.Test
    public void addAll() {
    }

    @org.junit.Test
    public void frequency() {
    }

    @org.junit.Test
    public void disjoint() {
    }

    @org.junit.Test
    public void testEquals() {
    }
}