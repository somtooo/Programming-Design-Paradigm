package wearable.jewelry;

/**
 * Describes the names of Jewelry currently used in the role playing game.
 */
public enum JewelryName {
    AMULET,
    NECKLACE,
    SCARAB,
    Collar,
    Brooch,
    Ribbon,
    BowTie,
    Chain,
    Pendant

}
